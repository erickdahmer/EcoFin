
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function BudgetCard({ title, amount }) {
  return (
    <View style={styles.card}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.amount}>R$ {amount}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: 16,
    margin: 10,
    backgroundColor: '#E0F2F1',
    borderRadius: 10
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold'
  },
  amount: {
    fontSize: 20,
    color: '#00796B'
  }
});
