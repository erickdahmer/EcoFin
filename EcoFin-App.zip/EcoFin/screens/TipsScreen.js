
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function TipsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.tip}>💡 Dica: Anote todos os seus gastos diários!</Text>
      <Text style={styles.tip}>💡 Dica: Evite compras por impulso.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20
  },
  tip: {
    fontSize: 18,
    marginBottom: 10
  }
});
