
import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import BudgetCard from '../components/BudgetCard';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Bem-vindo ao EcoFin</Text>
      <BudgetCard title="Gastos do mês" amount="1.200,00" />
      <Button title="Ver dicas" onPress={() => navigation.navigate('Dicas')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20
  },
  header: {
    fontSize: 24,
    marginBottom: 20
  }
});
